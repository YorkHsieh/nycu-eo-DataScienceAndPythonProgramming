import numpy as np
import pandas as pd
import os

# print(os.getcwd())
# print(" ")


######################## 6.1 Organizing Data ########################
# load data
# orders = pd.read_csv('../data/orders_C6_fixed.csv')      # orders_C6_fixed.csv
# products = pd.read_csv('../data/products_fixed.csv')
# customers = pd.read_csv('../data/customers_fixed.csv')

# print(f"orders = \n{orders}\n")
# print(f"products = \n{products}\n")
# print(f"customers = \n{customers}\n")

# print(orders.iloc[0])
# print(orders.order_id.iloc[0])
# print(type(orders))

############## 6.2 Inner Merge pd.merge().  ########################
# ### code_1 inner merge
# new_df = pd.merge(orders, customers)
# print(f"new_df = \n{new_df}\n")

# # code_2
# # pd.merge(orders, customers)
# # new_df = orders.merge(customers)

# ### code_3 chained inner merge
# big_df = orders.merge(customers).merge(products)
# print(f"big_df = \n{big_df}\n")

######################## 6.3 Name Collision ########################
# code_4 reload three csv files
# products and customers share the same name "id", 
# standing for 'product_id' and 'customer_id', respectively.

# orders = pd.read_csv('../data/orders_C6_fixed.csv')
# products = pd.read_csv('../data/products_id_fixed.csv')       # products_id_fixed.csv
# customers = pd.read_csv('../data/customers_id_fixed.csv')     # customers_id_fixed.csv

# print(f"orders = \n{orders}\n")          
# print(f"products = \n{products}\n")
# print(f"customers = \n{customers}\n")

# # code_5 renaming
# new_df = pd.merge(orders,customers.rename(columns={'id': 'customer_id'}))
# print(new_df)

# # code_6 left_on or right_on
# new_df = pd.merge(orders,customers, left_on='customer_id', right_on='id')
# print(new_df)


# ######################## 6.4  Outer Merge ########################
# code_7 reload three csv files
# new_orders = pd.read_csv('../data/new_orders_fixed.csv')
# products = pd.read_csv('../data/products_fixed.csv')

# print(f"new_orders = \n{new_orders}\n")
# print(f"products = \n{products}\n")

# # code_8 inner merge only merge common columns
# merged_df = pd.merge(new_orders, products)
# print(merged_df)

# code_9 outer merge: keep information from the unmatched rows 
# store_a = pd.read_csv('../data/store_a_fixed.csv')
# print(f"store_a = \n{store_a}\n")
# store_b = pd.read_csv('../data/store_b_fixed.csv')
# print(f"store_b = \n{store_b}\n")

# store_a_b_outer = pd.merge(store_a, store_b, how="outer")
# print(store_a_b_outer)


# ########## 6.5 Left and Right Merge (one-side missing) #############
# # code_10 left merge 
# store_a_b_left = pd.merge(store_a, store_b, how="left")
# print(store_a_b_left)

# # code_11 right merge 
# store_a_b_right = pd.merge(store_a, store_b, how="right")
# print(store_a_b_right)


# ########### 6.6 Concatenate DataFrames ######################

# # code_11 Concatenate DataFrames
# bakery = pd.read_csv('../data/bakery.csv')
# print(bakery)

# ice_cream = pd.read_csv('../data/ice_cream.csv')
# print(ice_cream)

# menu = pd.concat([bakery, ice_cream])
# print(menu)



########### Supplement ############

##### code S1 simple merge. #####
# df1A, df2A perfect matching values in merging key "Course"

# import pandas as pd

# df1A = pd.DataFrame({
#     'Student': ['Alice', 'Bob', 'Carol'],    # key: value
#     'Course': ['Python', 'Math', 'AI'],      
#     'Grade': [90, 80, 92]
# })

# df2A = pd.DataFrame({
#     'Course': ['Python', 'Math', 'AI'],
#     'Instructor': ['Prof. PY', 'Prof. MA', 'Prof. AI']
# })

# df3A = pd.merge(df1A, df2A)
# print(df3A)

##### code S2 union #####
# df1B, df1B mismatching values in merging key "Course"
# import pandas as pd

# df1B = pd.DataFrame({
#     "Student": ["Alice", "Bob", "Carol", "David"],
#     "Course": ["Python", "Math", "AI", "Python"],
#     "Grade": [90, 80, 92, 78]
# })

# df2B = pd.DataFrame({    
#     "Course": ["Python", "Math", "Machine Learning"],
#     "Instructor": ["Prof. PY", "Prof. MA", "Prof. ML"]
# })

# df3B = pd.merge(df1B, df2B, on="Course", how="outer")
# print(df3B)

##### code S3 left join #####
# df1B, df1B mismatching values in merging key "Course"
# import pandas as pd

# df1B = pd.DataFrame({
#     "Student": ["Alice", "Bob", "Carol", "David"],
#     "Course": ["Python", "Math", "AI", "Python"],
#     "Grade": [90, 80, 92, 78]
# })

# df2B = pd.DataFrame({    
#     "Course": ["Python", "Math", "Machine Learning"],
#     "Instructor": ["Prof. PY", "Prof. MA", "Prof. ML"]
# })

# df4B = pd.merge(df1B, df2B, on="Course", how="left")
# print(df4B)


##### code S4 simple vertical concatenation ("axis=0") #####
# df1C, df2C have the same keys

# import pandas as pd

# df1C = pd.DataFrame({
#     'Student': ['Alice', 'Bob', 'Carol'],
#     'Course': ['Python', 'Math', 'AI'],
#     'Grade': [90, 80, 92]
# })

# df2C = pd.DataFrame({
#     'Student': ['Deron', 'Eve'],
#     'Course': ['AI', 'Python'],
#     'Grade': [88, 95]
# })

# df3C = pd.concat([df1C, df2C], axis=0, ignore_index=True)
# print(df3C)


##### code S5 simple horizontal concatenation ("axis=1") #####
# df1C, df2C have the same keys

df1C = pd.DataFrame({
    'Student': ['Alice', 'Bob', 'Carol'],
    'Course': ['Python', 'Math', 'AI'],
    'Grade': [90, 80, 92]
})

df2C = pd.DataFrame({
    'Student': ['Deron', 'Eve'],
    'Course': ['AI', 'Python'],
    'Grade': [88, 95]
})

df4C = pd.concat([df1C, df2C], axis=1, ignore_index=True)
print(df4C)


